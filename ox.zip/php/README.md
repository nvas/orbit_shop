## View.php file contains the following:

    # head ... print html, head, style and start of body tags
    # foot ... print footer tag
    